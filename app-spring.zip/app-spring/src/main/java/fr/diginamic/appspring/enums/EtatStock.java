package fr.diginamic.appspring.enums;

public enum EtatStock {
    En_stock, epuise;
}
