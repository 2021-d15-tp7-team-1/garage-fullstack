package fr.diginamic.appspring.enums;

public enum  PrioriteTache {
    TresUrgent, Urgent, Normal, NonPrioritaire;
}
