package fr.diginamic.appspring.enums;

public enum ApplicationUserRole {
	ADMIN,
	CHEF,
	MAGASINIER,
	MECANICIEN,
	COMMERCIAL
}
