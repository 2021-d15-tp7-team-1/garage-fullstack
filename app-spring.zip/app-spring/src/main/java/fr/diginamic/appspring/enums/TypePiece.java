package fr.diginamic.appspring.enums;

public enum TypePiece {
    PIECE, ARTICLE
}
