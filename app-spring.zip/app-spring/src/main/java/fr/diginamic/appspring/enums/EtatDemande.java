package fr.diginamic.appspring.enums;

public enum EtatDemande {
    En_attent, Validée, Refusée;
}
