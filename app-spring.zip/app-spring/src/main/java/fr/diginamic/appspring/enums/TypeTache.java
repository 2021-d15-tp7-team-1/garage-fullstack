package fr.diginamic.appspring.enums;

public enum TypeTache {
    Vidange, Nettoyage, Pannes, Peinture;
}
