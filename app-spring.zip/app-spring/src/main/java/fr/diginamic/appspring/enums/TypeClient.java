package fr.diginamic.appspring.enums;

public enum TypeClient { ATELIER, VENTE }
