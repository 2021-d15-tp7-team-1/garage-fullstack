package fr.diginamic.appspring.enums;

public enum EtatVehicule {
    NEUF,OCCASION
}
