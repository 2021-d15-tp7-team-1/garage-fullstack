package fr.diginamic.appspring.entities;

import fr.diginamic.appspring.enums.TypeClient;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import java.util.HashSet;
import java.util.Set;

@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private TypeClient type;
    private String nom;
    private String prenom;
    @Column(name = "tel_Fixe")
    private String telfixe;
    @Column(name = "tel_Mobile")
    private String telmobile;

    @Embedded
    private Adresse adresse;

    @OneToMany(mappedBy = "client")
    private Set<FicheEntretien> fichesEntretien;

    @OneToMany(mappedBy = "client")
    private Set<DevisVehicule> devisVehicule;

    public Client() {
        fichesEntretien = new HashSet<FicheEntretien>();
        devisVehicule = new HashSet<DevisVehicule>();
    }

    public Client(TypeClient type, String nom, String prenom, String telFixe, String telMobile) {
        this.type = type;
        this.nom = nom;
        this.prenom = prenom;
        this.telfixe = telFixe;
        this.telmobile = telMobile;
        fichesEntretien = new HashSet<FicheEntretien>();
        devisVehicule = new HashSet<DevisVehicule>();
    }

    public void addFiche(FicheEntretien f) {
        if (f != null) {
            fichesEntretien.add(f);
            System.out.println("Fiche added");
        } else {
            System.err.println("Can't add a null fiche");
        }
    }

    public void addDevis(DevisVehicule d) {
        if (d != null) {
            devisVehicule.add(d);
            System.out.println("Devis added");
        } else {
            System.err.println("Can't add a null devis");
        }
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public TypeClient getType() {
        return type;
    }

    public void setType(TypeClient type) {
        this.type = type;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getTelfixe() {
        return telfixe;
    }

    public void setTelfixe(String telfixe) {
        this.telfixe = telfixe;
    }

    public String getTelmobile() {
        return telmobile;
    }

    public void setTelmobile(String telmobile) {
        this.telmobile = telmobile;
    }

    public Set<FicheEntretien> getFichesEntretien() {
        return fichesEntretien;
    }

    public void setFichesEntretien(Set<FicheEntretien> fichesEntretien) {
        this.fichesEntretien = fichesEntretien;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }

    public Set<DevisVehicule> getDevisVehicule() {
        return devisVehicule;
    }

    public void setDevisVehicule(Set<DevisVehicule> devisVehicule) {
        this.devisVehicule = devisVehicule;
    }
}
